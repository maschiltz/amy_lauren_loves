﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'fi', {
	btnIgnore: 'Jätä huomioimatta',
	btnIgnoreAll: 'Jätä kaikki huomioimatta',
	btnReplace: 'Korvaa',
	btnReplaceAll: 'Korvaa kaikki',
	btnUndo: 'Kumoa',
	changeTo: 'Vaihda',
	errorLoading: 'Virhe ladattaessa oikolukupalvelua isännältä: %s.',
	ieSpellDownload: 'Oikeinkirjoituksen tarkistusta ei ole asennettu. Haluatko ladata sen nyt?',
	manyChanges: 'Tarkistus valmis: %1 sanaa muutettiin',
	noChanges: 'Tarkistus valmis: Yhtään sanaa ei muutettu',
	noMispell: 'Tarkistus valmis: Ei virheitä',
	noSuggestions: 'Ei ehdotuksia',
	notAvailable: 'Valitettavasti oikoluku ei ole käytössä tällä hetkellä.',
	notInDic: 'Ei sanakirjassa',
	oneChange: 'Tarkistus valmis: Yksi sana muutettiin',
	progress: 'Tarkistus käynnissä...',
	title: 'Oikoluku',
	toolbar: 'Tarkista oikeinkirjoitus'
});
