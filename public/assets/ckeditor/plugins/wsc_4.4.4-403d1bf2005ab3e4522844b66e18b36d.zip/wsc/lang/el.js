﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'el', {
	btnIgnore: 'Αγνόηση',
	btnIgnoreAll: 'Αγνόηση όλων',
	btnReplace: 'Αντικατάσταση',
	btnReplaceAll: 'Αντικατάσταση όλων',
	btnUndo: 'Αναίρεση',
	changeTo: 'Αλλαγή σε',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Δεν υπάρχει εγκατεστημένος ορθογράφος. Θέλετε να τον κατεβάσετε τώρα;',
	manyChanges: 'Ο ορθογραφικός έλεγχος ολοκληρώθηκε: Άλλαξαν %1 λέξεις',
	noChanges: 'Ο ορθογραφικός έλεγχος ολοκληρώθηκε: Δεν άλλαξαν λέξεις',
	noMispell: 'Ο ορθογραφικός έλεγχος ολοκληρώθηκε: Δεν βρέθηκαν λάθη',
	noSuggestions: '- Δεν υπάρχουν προτάσεις -',
	notAvailable: 'Η υπηρεσία δεν είναι διαθέσιμη αυτήν την στιγμή.',
	notInDic: 'Δεν υπάρχει στο λεξικό',
	oneChange: 'Ο ορθογραφικός έλεγχος ολοκληρώθηκε: Άλλαξε μια λέξη',
	progress: 'Γίνεται ορθογραφικός έλεγχος...',
	title: 'Ορθογραφικός Έλεγχος',
	toolbar: 'Ορθογραφικός Έλεγχος'
});
